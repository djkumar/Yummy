<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;

Class UsersController extends Controller{


 public function __construct()
    {
        $this->middleware('auth:admin');
    }


public function index(){
	$users = User::orderBy('created_at', 'desc')->get();

	 return view('backend.users')->withUsers($users);
}

}


?>