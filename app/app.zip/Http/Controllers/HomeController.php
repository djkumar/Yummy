<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Jcf\Geocode\Geocode;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


$response = Geocode::make()->latLng(40.7637931,-73.9722014);
if ($response) {
    echo $response->latitude();
    echo $response->longitude();
    echo $response->formattedAddress();
    echo $response->locationType();
}


        return view('home')->with($response);
    }
}
