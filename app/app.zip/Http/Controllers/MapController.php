<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

Class MapController extends Controller { 

public function index(){ 
 return view('map');
}

public function show(){ 
 return view('map');

}


}



?>